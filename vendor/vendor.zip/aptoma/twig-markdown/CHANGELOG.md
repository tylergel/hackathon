CHANGELOG
=========

2.0.0
-----

- **BC**: Require Twig v1.12, in order to replace deprecated Twig_Filter_Method with Twig_SimpleFilter
- **Added**: Add support for ParsedownEnging

1.2.0
-----

- **Added**: Add support for GitHub's markdown engine

1.1.0
-----

- **Added**: Add support for PHP League CommonMark engine

1.0.0
-----

- **BC**: Remove deprecated dflydev-markdown parser
